#include <stdlib.h>
#include <stdio.h>
#include "funcoes-hash.h"

int main(){
    //Inicializar tabela
    est_tabelaHash tabelaHash;
    inicializaTabHash(&tabelaHash);

    //Padrão de chaves, entre 1000, 1099;
    int chave = 1000;

    //Inserir na tabela
    insereTabHash(&tabelaHash, chave, 32, 31);

    //Remover da tabela

    //Buscar na tabela
    est_no_hash *noEncontrado = buscaTabHash(&tabelaHash, chave);
    if (noEncontrado == NULL){
        printf("Esse dado não esta cadastrado!\n");
    }
    else{
        printf("Dado encontrado!\n");
        printf("Dado 1: [%d]\n", noEncontrado->dado1);
    }

    //Mostrar tabela
    mostraTabHash(tabelaHash);
    

}

